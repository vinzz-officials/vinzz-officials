function buyProduct(product, price) {
    const message = `Bang mau beli ${product} ${price}`;
    const whatsappLink = `https://wa.me/6283197848916?text=${encodeURIComponent(message)}`;
    window.open(whatsappLink, '_blank');
}
